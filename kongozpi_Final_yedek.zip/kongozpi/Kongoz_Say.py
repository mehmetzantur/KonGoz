# -*- coding: utf-8 -*-
import os 
import time
import pygame
 	

def Alert():
	os.system('mpg321 "{0}"'.format("/home/pi/Desktop/kongozpi/newalert.mp3"))

def Save(number,text):
        os.system('espeak -vtr+m3 -s150 -w /home/pi/Desktop/kongozpi/wav/"{0}".wav "{1}"'.format(number,text.encode('utf-8')))

def Say(number):
	
##	os.system("aplay wav/{0}.wav".format(number))
	
	pygame.mixer.init()
	pygame.mixer.music.load("/home/pi/Desktop/kongozpi/wav/{0}.wav".format(number))
	pygame.mixer.music.play()
	while pygame.mixer.music.get_busy() == True:
            continue
def SS():
    os.system('espeak -vtr+m3 -s150 ')

def Start():
    os.system('espeak -vtr+m3 -s150 Görüntü:İşleniyor.')
    
def Capture():
    os.system('espeak -vtr+m3 -s150 Görüntü:Alınıyor.')
    
def Next():
    os.system('espeak -vtr+m3 -s150 Sayfayı:Çevirin.')
    
def PowerOff():
    os.system('espeak -vtr+m3 -s150 Sistem:Kapatılıyor.')

def timeNow():
    timeNow = 'Saat:' +  str(time.strftime('%H:%M'))
    os.system('espeak -vtr+m3 -s150 {0}'.format(timeNow))

def Control():
        pygame.mixer.init()
	pygame.mixer.music.load("/home/pi/Desktop/kongozpi/control.wav")
	pygame.mixer.music.play()
	while pygame.mixer.music.get_busy() == True:
            continue
        
    #text = "sistem aktif"
    #os.system('espeak -vtr+m3 -s150 -w control.wav "{0}"'.format(text.encode('utf-8')))